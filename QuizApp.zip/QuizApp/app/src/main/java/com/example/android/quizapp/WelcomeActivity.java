package com.example.android.quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {

    //Declaring the components of our view
    EditText studnameBox, studnumberBox;
    Button continueButton;

    String errorMessage = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);//This line is used to connect or bind a layout activity resource view file to it java activity class

        initialUIcomponents(); //This is going to call the method
    }

    //This method is going to be used to initialize our component
    private void initialUIcomponents(){
        studnameBox = (EditText)findViewById(R.id.studname);
        studnumberBox = (EditText)findViewById(R.id.stdnumber);

        continueButton = (Button)findViewById(R.id.continuebutton);
    }

    //This is an onclick event that we declared in the layout view of the activity.
    //This is already tied to the button component
    public void continueButton(View view){

        String studentname = studnameBox.getText().toString();
        String studentnumber = studnumberBox.getText().toString();

        //Now we need to validate to ensure that the user does not continue to do exam without entering the name and number
        errorMessage = validateUserinput(studentname, studentnumber);

        if(errorMessage != null){
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
        }
        else{
            Intent intent = new Intent (WelcomeActivity.this,QuizActivity.class);

            //Please note that the putExtra is used to pass values to the next activity
            intent.putExtra("studentname",studentname);
            intent.putExtra("studentnumber",studentnumber);

            startActivity(intent);
        }
    }

    //This is the method that we are going to use to validate
    private String validateUserinput(String studentname, String studentnumber){

        if(studentname == null || studentnumber == null){
            errorMessage = "You forgot to enter your name or your number";
        }

        else if(studentname != null && studentnumber != null && studentname.trim().length() < 1 && studentnumber.trim().length() < 1){

            errorMessage = "You forgot to enter your name or your number";
        }
        else
        {
            errorMessage= null;//This is going to set the error message to be completely null if there is not error in user filling the form
        }

        return errorMessage;
    }

}
