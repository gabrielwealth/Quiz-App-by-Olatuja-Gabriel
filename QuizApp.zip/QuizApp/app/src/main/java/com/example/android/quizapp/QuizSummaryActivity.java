package com.example.android.quizapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class QuizSummaryActivity extends AppCompatActivity {

    //Declaring all components and vaiables for this activity
    TextView summarytext = null;

    private String summary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_summary);

        //we are giong to get the summary and display to the user
        summarytext = (TextView)findViewById(R.id.summary);

        summary = collectSummary();

        summarytext.setText(summary); //This is the statement that would make it visible to the user or student
    }

    //We are going to create a method to collect values passed by previous activity
    private String collectSummary(){

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if(bundle != null){
            summary = intent.getStringExtra("summary");
        }

        Log.i("summary",summary);

        return summary;
    }

    public void sendEmail(View view){

       String subject = "Quiz Test Summary";
               //Email intent
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, summary);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
