package com.example.android.quizapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class QuizActivity extends AppCompatActivity {



    // Method holds Question Library Object
    private QuestionLibrary mQuestionLibrary = new QuestionLibrary();

    Context context = QuizActivity.this;

    //Declare an iterator to loop throuh the array containers
    int iterator =0;


    //Method holds the variable for the score.
    private TextView mScoreView;
    //Method holds the variable for the Questions.
    private TextView mQuestionView;

    private RadioGroup radiogroup;
    //Method holds the variable for the Choices.
    private Button mRadioButtonChoice1;
    private Button mRadioButtonChoice2;
    private Button mRadioButtonChoice3;
    private Button mRadioButtonChoice4;
    //Method holds the variable for the for Submit Button.
    private Button mSubmitButton;

    //Method holds variable for the answer.
    private String mAnswer;

    //Method holds the score.
    private int mScore = 0;

    //Method holds question numbers.
    private int mQuestionNumber = 0;

    //These variables below would be used to collect information passed from the previous Activity intent
    private String studentname, studentnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        //Method displays actionbar
        Toolbar toolbar = findViewById(R.id.action_bar);










        //Collect information from the previous activity
        collectStudentinfo();

        //Method connects the variables to the views in the xml.
        mQuestionView = (TextView) findViewById(R.id.question);

        radiogroup = (RadioGroup) findViewById(R.id.radiogroup);

        mRadioButtonChoice1 = (RadioButton) findViewById(R.id.choiceA);
        mRadioButtonChoice2 = (RadioButton) findViewById(R.id.choiceB);
        mRadioButtonChoice3 = (RadioButton) findViewById(R.id.choiceC);
        mRadioButtonChoice4 = (RadioButton) findViewById(R.id.choiceD);
        mSubmitButton = (Button) findViewById(R.id.submitButton);


        //Show the first question to the user
        displayQuestion();
    }

    private void collectStudentinfo(){

        Intent intent = getIntent();//This is going to return the previous intent that came to this activity
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            studentname = intent.getStringExtra("studentname");
            studentnumber = intent.getStringExtra("studentnumber");

            Log.i("student info", studentname +" "+studentnumber);
        }
        else{
            Log.i("student info","No value passed");
        }
    }



    /***************************Click methods **************************************/
    //Method displays the clicks on the option buttons.

    public void pickOptiona(View view){
        String option = "a";
        choosenAnswer(option);
    }
    public void pickOptionb(View view){
        String option = "b";
        choosenAnswer(option);
    }
    public void pickOptionc(View view){
        String option = "c";
        choosenAnswer(option);
    }
    public void pickOptiond(View view){
        String option = "d";
        choosenAnswer(option);
    }



    //We would create an ehlper method that would help to send the answer that the user clicked
    private void choosenAnswer(String optionpicked){

        mQuestionLibrary.studentsAnswers[iterator] = optionpicked; //This line is giogn to store the option that the user picked while doing the exam.

        Log.v("option",mQuestionLibrary.studentsAnswers[iterator]+"  "+iterator);
    }

    public void showNext(View view){

        int quesno = mQuestionLibrary.mQuestion.length;

        iterator++;

        Log.i("qno",iterator+"");

        if(iterator > (quesno-1)) {
            Toast.makeText(this, "You have reached the last question", Toast.LENGTH_SHORT).show();
            iterator = (quesno-1);
        }else {
            radiogroup.clearCheck();

            displayQuestion();//Call to the method

            showChoosenAns(); //This is going to call the method that would show previously selected answers
        }
    }


    //This method is for showing previous question
    public void showPrev(View view){

        int quesno = mQuestionLibrary.mQuestion.length; //This is suppose to get the total number of questions

        iterator--;

        if(iterator < 0) {
            Toast.makeText(this, "You have reached the first question", Toast.LENGTH_SHORT).show();
            iterator=0; //Set iterator to be zero. So it stays at the first question
        }
        else{
            radiogroup.clearCheck(); //This is usd to clear the users option that was previously selected when answering questions. This is suppose to ensure that a user does not see a previous selected answer when he moves to the next question

            displayQuestion(); //Call to the method

            showChoosenAns(); //This is going to call the method that would show previously selected answers
        }
    }

    //This method is a private methot that would be used to display question and options
    private void displayQuestion(){
        //This displays questions
        String question = mQuestionLibrary.mQuestion[iterator];
        mQuestionView.setText(question);

        //This would display option A
        String optiona = mQuestionLibrary.Optiona[iterator]; // This line is going to get me the option a of the question am viewing
        mRadioButtonChoice1.setText(optiona);

        //This would be used to display the Option B
        String optionb = mQuestionLibrary.Optionb[iterator];
        mRadioButtonChoice2.setText(optionb);

        //This would be used to disply the option C
        String optionc = mQuestionLibrary.Optionc[iterator];
        mRadioButtonChoice3.setText(optionc);

        //This would be used to display option D.
        String optiond = mQuestionLibrary.Optiond[iterator];
        mRadioButtonChoice4.setText(optiond);
    }


    //We are going to create a method that would display the optoion that the user selected on previous questions
    private void showChoosenAns(){

        String currentChoosenAns = mQuestionLibrary.studentsAnswers[iterator]; //This statement is going to pick the choosen answer that the student choose for the particular question that we currently viewing at the moment

        if(currentChoosenAns.length() >0){
            if(currentChoosenAns.equals("a")){

                ((RadioButton)radiogroup.getChildAt(0)).setChecked(true);
            }
            else if(currentChoosenAns.equals("b")){

                ((RadioButton)radiogroup.getChildAt(1)).setChecked(true);
            }
            else if(currentChoosenAns.equals("c")){

                ((RadioButton)radiogroup.getChildAt(2)).setChecked(true);
            }
            else if(currentChoosenAns.equals("d")){

                ((RadioButton)radiogroup.getChildAt(3)).setChecked(true);
            }
        }
    }

    //This is method that would help submit users answers
    public void submitExam(View view){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage(R.string.confirmsg); //This is giong to show the message that would be displayed to the user when he opens the confirm dialog box
// Add the buttons
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                // User clicked OK button
                int score = calculateScore();
                Log.v("score",""+score);

                //Toast.makeText(context, "Your score is "+score,Toast.LENGTH_SHORT).show();

                String summary =generatequizSummary(score);

                //I would pass the summary to the summary activity
                Intent intent = new Intent(context, QuizSummaryActivity.class);

                //Dont forget to pass the summary inside the intent
                intent.putExtra("summary", summary);

                startActivity(intent);
            }
        });
        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
                dialog.cancel();
            }
        });
// Set other dialog properties

// Create the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //This method wouild be used to calculate correct answers
    private int calculateScore(){

        int score = 0;

        String[] correctans = mQuestionLibrary.mCorrectAns; //This is were the correct answers are stored
        String[] studentans = mQuestionLibrary.studentsAnswers; //This is were the student answers are stored

        //We need to compare both answers for all questions to calculate the score
        //This is going to be used to iterate through the questions and find the correct answers
        for(int qnumber = 0; qnumber< mQuestionLibrary.mQuestion.length; qnumber++){

            if(studentans[qnumber].length() >0){ //This condition helps check for questions that were answered

                if(studentans[qnumber].equals(correctans[qnumber]) == true){

                    score++;
                }
            }
        }

        return score;
    }

    //Now we are creating this method to generate exam summary
    private String generatequizSummary(int score){

        int totalques = mQuestionLibrary.mQuestion.length;

        Log.i("score and total", score+" "+totalques);

        float studentpercentage = calculatePercentage(score, totalques);

        String summary = "";

        summary = "Student name : "+studentname+"\n"; // += is used to concatenate strings in different lines
        summary += "Student number : "+studentnumber+"\n";
        summary += "Score : "+score +"\t Total Questions : "+totalques+" \n";
        summary += "Percentage score : "+studentpercentage +"% \n";
        summary += "\n";
        summary += "-------------------------------------------------\n";
        summary += quizDetails();

        return summary;
    }

    //This method is going to  be used to display quiz details
    private String quizDetails(){

        String details = "";

        String[] questions = mQuestionLibrary.mQuestion;
        String[] mCorrectAnswers = mQuestionLibrary.mCorrectAnswers;
        String[] correctoptions = mQuestionLibrary.mCorrectAns; //This is were the correct options (It stores a, b , c like values)
        String[] studentans = mQuestionLibrary.studentsAnswers; //This is were the student answers are stored

        //We need to compare both answers for all questions to display detailed summary
        //This is going to be used to iterate through to display summary on every questions and users choosen answer
        for(int qnumber = 0; qnumber< mQuestionLibrary.mQuestion.length; qnumber++) {

            details +=  questions[qnumber] + "\n";

            if(studentans[qnumber].equals(correctoptions[qnumber]) == true){
                details += "[Correct]  Your answer ("+studentans[qnumber]+") \nCorrect answer ("+correctoptions[qnumber]+ ") ("+mCorrectAnswers[qnumber]+") \n\n";
            }
            else{
                details += "[Wrong]  Your answer ("+studentans[qnumber]+") \nCorrect answer ("+correctoptions[qnumber]+ ") ("+mCorrectAnswers[qnumber]+") \n\n";
            }
        }

        return details;
    }

    //This method would be used to calculate the percentage of the student
    private float calculatePercentage(int score, float totalques){
        float result = (score/totalques) * 100;
        return Math.round(result); //Rounding of % to whole number
    }
}
