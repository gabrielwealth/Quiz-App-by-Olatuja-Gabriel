package com.example.android.quizapp;

public class QuestionLibrary {
    //Array of questions
    public String mQuestion[] = {
            "1. How many eggs can we get in a dozen?",
            "2. What is the full meaning of URI?",
            "3. Which of the following is IDE for android app development?",
            "4. Which of the following is not an arithmetic operator?",
            "5. IDE means____?",

    };

    //This is an array container to store the option a values for all the questions.
    public String Optiona[] = {
            "a. 15",
            "a. Uniform Random Index",
            "a. GitSuite",
            "a. Addition",
            "a. Integrated Development Export"
    };

    public String Optionb[] = {
            "b. 12",
            "b. Unverified Resource Identifier",
            "b. Gitbash",
            "b. Less than",
            "b. Integrated Development Environment"

    };

    public String Optionc[] = {
            "c. 20",
            "c. Uniform Resource Identifier",
            "c. Github",
            "c. Multiplication",
            "c. Interphase Development Environment"
    };

    public String Optiond[] = {
            "d. 120",
            "d. Uninterrupted Resource Identifier",
            "d. Android Studio",
            "d. Subtraction",
            "d. Integrated Developmental Environ",

    };

    //This array is giong to be used to store the student answers
    public String studentsAnswers [] = {
            "","","","",""
    };
    //0,1,2,3,4  iterator

    public String mCorrectAnswers[] = {"12", "Uniform Resource Identifier", "Android Studio", "Less than", "Integrated Development Environment"};

    public String mCorrectAns[] = { "b","c","d","b","b"};
}


